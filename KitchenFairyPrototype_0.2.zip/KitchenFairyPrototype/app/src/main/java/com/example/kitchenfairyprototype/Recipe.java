package com.example.kitchenfairyprototype;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.util.ArrayList;

public class Recipe extends ItemModel implements Serializable {
    //ItemModel specifically for recipes

    public Recipe(int id, String name, ArrayList<String> items, ArrayList<String> instructions) {
        super(id, name, items, instructions);
    }

    @NonNull
    @Override
    public String toString() {
        return super.toString();
    }
}
