package com.example.kitchenfairyprototype;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class ItemViewer extends AppCompatActivity {

    ArrayAdapter<String> itemAdapter;
    FloatingActionButton itemFab;
    FloatingActionButton fabToList;
    Bitmap bmpLogo, scaledBmpLogo; //for applying the logo to PDFs
    Bitmap recipeImg; //for printing the recipe image to the PDF
    Uri uri;
    ItemModel model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);
        //get intent and import the ItemModel sent by last activity
        Intent i = getIntent();
        Bundle bundle = i.getParcelableExtra("ItemModel_bundle");
        model = (ItemModel) bundle.getSerializable("ItemModel");

        itemFab = findViewById(R.id.fabItems);
        fabToList = findViewById(R.id.fabToList);
        bmpLogo = BitmapFactory.decodeResource(getResources(), R.drawable.kitchen_fairy_circle);
        scaledBmpLogo = Bitmap.createScaledBitmap(bmpLogo, 120, 120, false);

        ActivityCompat.requestPermissions(this,new String[]{
            Manifest.permission.WRITE_EXTERNAL_STORAGE}, PackageManager.PERMISSION_GRANTED);

        //code to view items
        if (model.notes == null) {
            ImageView itemImg = findViewById(R.id.itemImg);
            itemImg.setVisibility(View.GONE);
            itemFab.setVisibility(View.GONE);
            fabToList.setVisibility(View.GONE);
            viewShopping((Shopping) model);
        } else {
            if (model.imgUri != null) {
                uri = Uri.parse(model.imgUri);

            }
            viewRecipe((Recipe) model);
        }


        itemFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createPdf(model);

            }
        });

        fabToList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //package the ingredients to be sent via bundle
                Bundle bundle = new Bundle();
                bundle.putStringArrayList("ingredients", model.items);
                //start shopping list editor by intent
                Intent intent = new Intent(getApplicationContext(), ShopEditor.class);
                intent.putExtra("ingredient_bundle", bundle);
                startActivity(intent);
            }
        });

    } //end oncreate

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ContentResolver contentResolver = getApplicationContext().getContentResolver();
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
// Check for the freshest data.
        contentResolver.takePersistableUriPermission(uri, takeFlags);

    }

    //view shopping lists
    public void viewShopping(Shopping model) {
        //find each view to populate. excludes img and notes
        ListView items;
        items = findViewById(R.id.items);
        TextView name;
        name = findViewById(R.id.itemName);
        //set the name of the model
        name.setText(model.name);
        //set the adapter to fill items
        itemAdapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1, model.items);
        items.setAdapter(itemAdapter);
    }

    public void viewRecipe(Recipe model) {
        //find each view to populate.
        ListView items;
        items = findViewById(R.id.items);
        TextView name;
        name = findViewById(R.id.itemName);
        ImageView img;
        img = findViewById(R.id.itemImg);
        ListView notes;
        notes = findViewById(R.id.notes);

        name.setText(model.name);
        itemAdapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1, model.items);
        items.setAdapter(itemAdapter);
        itemAdapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1, model.notes);
        notes.setAdapter(itemAdapter);
        img.setImageURI(uri);
    }

    private void createPdf(ItemModel recipe) {
        String pdfPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
        File file = new File(pdfPath, "placeholder.pdf"); //replace placeholder with generated string from recipe name

        String name = recipe.name;
        ArrayList<String> ingredients = recipe.items;
        ArrayList<String> instructions = recipe.notes;

        PdfDocument pdfDocument = new PdfDocument();
        Paint pdfPaint = new Paint();

        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(400,600,1).create();
        PdfDocument.Page page1 = pdfDocument.startPage(pageInfo);

        Canvas canvas = page1.getCanvas();

        int pw = page1.getInfo().getPageWidth();
        int ph = page1.getInfo().getPageHeight();

        pdfPaint.setColor(Color.rgb(219,169,112));
        canvas.drawRect(0,0,pw,35,pdfPaint);
        canvas.drawRect(0,ph - 35,pw,ph,pdfPaint);

        pdfPaint.setColor(Color.rgb(0,0,0));

        pdfPaint.setTextSize(15.0f);
        canvas.drawText(name, 30,70, pdfPaint);
        //set starting Y for ingredients
        pdfPaint.setTextSize(11.0f);
        int Y = 90;
        //print ingredients
        for(String ing : ingredients){
            canvas.drawText(ing, 30, Y, pdfPaint);
            Y += 12;
        }
        //add space
        Y += 20;
        int listNum = 1;
        //print instructions
        for(String ins : instructions){
            String item = listNum + ". " + ins;
            canvas.drawText(item, 30, Y, pdfPaint);
            Y += 14;
            listNum += 1;
        }

        //draw logo
        canvas.drawBitmap(scaledBmpLogo, pw - 130, 10, pdfPaint);


        //Finish page 1
        pdfDocument.finishPage(page1);

        try {
            pdfDocument.writeTo(new FileOutputStream(file));
        } catch (IOException e){
            e.printStackTrace();
        }

        pdfDocument.close();
    }

}
