package com.example.kitchenfairyprototype;

import java.io.Serializable;
import java.util.ArrayList;

public class ItemModel implements Serializable {
    //an abstract representation of a recipe book item and data

    protected int id;
    protected String name;
    protected ArrayList<String> items;
    protected ArrayList<String> notes;

    //constructor
    public ItemModel(int id, String name, ArrayList<String> items, ArrayList<String> notes) {
        this.id = id;
        this.name = name;
        this.items = items;
        this.notes = notes;
    }

    @Override
    public String toString() {
        return name;
    }
}
