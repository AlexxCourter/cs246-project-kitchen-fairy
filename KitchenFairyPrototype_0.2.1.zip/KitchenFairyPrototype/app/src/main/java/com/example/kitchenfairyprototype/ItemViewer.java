package com.example.kitchenfairyprototype;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.Serializable;

public class ItemViewer extends AppCompatActivity {

    ArrayAdapter<String> itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);
        //get intent and import the ItemModel sent by last activity
        Intent i = getIntent();
        Bundle bundle = i.getParcelableExtra("ItemModel_bundle");
        ItemModel model = (ItemModel) bundle.getSerializable("ItemModel");

        //code to view items
        if (model instanceof Shopping) {
            viewShopping((Shopping) model);
        } else {
            viewRecipe((Recipe) model);
        }
    }

    //view shopping lists
    public void viewShopping(Shopping model) {
        //find each view to populate. excludes img and notes
        ListView items;
        items = findViewById(R.id.items);
        TextView name;
        name = findViewById(R.id.itemName);
        //set the name of the model
        name.setText(model.name);
        //set the adapter to fill items
        itemAdapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1, model.items);
        items.setAdapter(itemAdapter);
    }

    public void viewRecipe(Recipe model) {
        //find each view to populate.
        ListView items;
        items = findViewById(R.id.items);
        TextView name;
        name = findViewById(R.id.itemName);
        ImageView img;
        img = findViewById(R.id.itemImg);
        ListView notes;
        notes = findViewById(R.id.notes);

        name.setText(model.name);
        itemAdapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1, model.items);
        items.setAdapter(itemAdapter);
        itemAdapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1, model.notes);
        notes.setAdapter(itemAdapter);
    }

}
