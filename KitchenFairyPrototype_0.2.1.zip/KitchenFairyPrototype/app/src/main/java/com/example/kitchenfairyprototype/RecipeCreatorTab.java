package com.example.kitchenfairyprototype;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kitchenfairyprototype.ui.main.SectionsPagerAdapter;
import com.example.kitchenfairyprototype.databinding.ActivityRecipeEditorTabBinding;

import java.util.ArrayList;


/** RecipeCreatorTab activity edits and saves a recipe
 * called by RecipeList floating action button
 * utilizes a tab for the name and ingredients, and a separate tab for instructions
 *
 * */
public class RecipeCreatorTab extends AppCompatActivity {

    private ActivityRecipeEditorTabBinding binding;
    protected TextView recipeName;
    //contains the actual recipe data
    protected ArrayList<String> ingredients = new ArrayList<>();
    protected ArrayList<String> instructions = new ArrayList<>();
    //contains reference to the editable TextViews in the Activity
    protected ArrayList<TextView> viewList = new ArrayList<>();
    protected ArrayList<TextView> instructionList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityRecipeEditorTabBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = binding.viewPager;
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = binding.tabs;
        tabs.setupWithViewPager(viewPager);
        FloatingActionButton fab = binding.fab;
        Context context = this.getApplicationContext();


        /** OnClickListener for the floating action button
         * Saves the user input for recipe name, and both ingredients and instructions
         * then adds the new recipe to the UserReference and saves it to app data file
         * Once the UserReference is updated with the new recipe, a toast displays
         * that the recipe was saved and opens the RecipeList activity.
         * */
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DataController dc = new DataController();
                final String TAG = "fab";
                //get the TextView references for user inputs
                setVariables();
                //save user inputs to ingredients and instructions respectively.
                ingredients = getIngredients();
                instructions = getInstructions();
                //access UserReference and save
                Log.d(TAG, "ingredients: " + ingredients);
                Log.d(TAG, "Instructions: " + instructions);
                UserReference user = UserReference.getInstance();
                int incrementID = user.getRecipeIDHolder() + 1;
                String name = String.valueOf(recipeName.getText());
                Recipe recipe = new Recipe(incrementID, name, ingredients, instructions);
                user.recipes.add(recipe);
                //prompt the UserReference to save data
                //update current user with new data
                UserReference.updateReferenceRecipe(user);
                dc.saveReference(context);

                //Make this the save button. Display "Recipe Saved" in a toast.
                Toast.makeText(getApplicationContext(), "Recipe saved", Toast.LENGTH_SHORT).show();
                //go back to the recipe list. This should clear any lists made here so duplication error ceases
                Intent intent = new Intent(RecipeCreatorTab.this, RecipeList.class);
                startActivity(intent);
            }
        });
    }

    /**
     * Helper function that loops through the ingredient TextViews and adds their
     * values to the list of ingredients for the recipe.
     *
     * @return ArrayList of String values representing the ingredients of the recipe
     * */
    public ArrayList<String> getIngredients() {
        ArrayList<String> ingredients = new ArrayList<>();
        for (TextView t : viewList) {
            if (t != null) {
                ingredients.add(String.valueOf(t.getText()));
            }
        }
        return ingredients;
    }

    /**
     * Helper function that loops through the instruction TextViews and adds their
     * values to the list of instructions for the recipe.
     *
     * @return ArrayList of String values representing the instructions of the recipe
     * */
    public ArrayList<String> getInstructions() {
        ArrayList<String> instructions = new ArrayList<>();
        for (TextView t : instructionList) {
            if (t != null) {
                instructions.add(String.valueOf(t.getText()));
            }
        }
        return instructions;
    }

    public void prePopulateFields(Recipe recipe){
        //populates the editor fields with a selected recipe
        //use setVariables to grab all the fields
        //get text views

        //set name
        //recipeName.setText((CharSequence) recipe.name);
        //set the ingredients and instructions into their respective textViews
        for (String i : ingredients){
            int index = 0;
            i = recipe.items.get(index);
            index += 1;
        }
        for (String i : instructions){
            int index = 0;
            i = recipe.notes.get(index);
            index += 1;
        }
        for (TextView tv : viewList) {
            int index = 0;
            tv.setText(recipe.items.get(index));
            index += 1;
        }
        for (TextView tv : instructionList) {
            int index = 0;
            tv.setText(recipe.notes.get(index));
            index += 1;
        }
    }

    /**
     * Helper function that gets all the editable views and adds their data to each list
     * */
    public void setVariables() {
        //grab the ID of the recipe name box
        recipeName = findViewById(R.id.recipeName);

        //find all view ID so they can be captured with a loop function at saving time
        viewList.add(findViewById(R.id.ingredient1));
        viewList.add(findViewById(R.id.ingredient2));
        viewList.add(findViewById(R.id.ingredient3));
        viewList.add(findViewById(R.id.ingredient4));
        viewList.add(findViewById(R.id.ingredient5));
        viewList.add(findViewById(R.id.ingredient6));
        viewList.add(findViewById(R.id.ingredient7));
        viewList.add(findViewById(R.id.ingredient8));
        viewList.add(findViewById(R.id.ingredient9));

        //find the instructions
        instructionList.add(findViewById(R.id.instruct1));
        instructionList.add(findViewById(R.id.instruct2));
        instructionList.add(findViewById(R.id.instruct3));
        instructionList.add(findViewById(R.id.instruct4));
        instructionList.add(findViewById(R.id.instruct5));
        instructionList.add(findViewById(R.id.instruct6));
        instructionList.add(findViewById(R.id.instruct7));
        instructionList.add(findViewById(R.id.instruct8));
        instructionList.add(findViewById(R.id.instruct9));
        instructionList.add(findViewById(R.id.instruct10));
    }



}