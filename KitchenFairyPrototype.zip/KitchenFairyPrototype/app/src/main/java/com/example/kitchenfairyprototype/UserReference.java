package com.example.kitchenfairyprototype;

import java.util.ArrayList;

public class UserReference {
    //member variables
    private int recipeIDHolder;
    private int shoppingIDHolder;
    private String username;
    protected ArrayList<ItemModel> shoppingLists;
    protected ArrayList<ItemModel> recipes;

    //constructor
    public void UserReference(int rID, int sID, String user) {
        this.recipeIDHolder = rID;
        this.shoppingIDHolder = sID;
        this.username = user;
    }


    //getters and setters
    public int getRecipeIDHolder() {
        return recipeIDHolder;
    }

    public void setRecipeIDHolder(int recipeIDHolder) {
        this.recipeIDHolder = recipeIDHolder;
    }

    public int getShoppingIDHolder() {
        return shoppingIDHolder;
    }

    public void setShoppingIDHolder(int shoppingIDHolder) {
        this.shoppingIDHolder = shoppingIDHolder;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void reset() {
        //display a message, then reset the user data if the user affirms
    }
}
