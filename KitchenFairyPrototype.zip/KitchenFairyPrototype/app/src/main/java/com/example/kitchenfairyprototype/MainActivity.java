package com.example.kitchenfairyprototype;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private UserReference user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //read saved data and apply to UserReference


        //button event listeners. These need to be instantiated somewhere with activity callback, like the onCreate method
        //Recipes button
        Button btnRecipe = findViewById(R.id.btnRecipe);
        btnRecipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String TAG = "MainActivity";
                Log.d(TAG, "Opening RecipeList activity");
                Log.d(TAG, "About to create intent with Recipe Lists");

                Intent intent = new Intent(MainActivity.this, RecipeList.class);
                startActivity(intent);
            }
        });
        //Shopping Lists button
        Button btnShopping = findViewById(R.id.btnShopping);
        btnShopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String TAG = "MainActivity";
                Log.d(TAG, "Opening ShoppingLists activity");
                Log.d(TAG, "About to create intent with Shopping Lists");

                Intent intent = new Intent(MainActivity.this, ShopList.class);
                startActivity(intent);
            }
        });
    }

}