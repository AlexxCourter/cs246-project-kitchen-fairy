package com.example.kitchenfairyprototype;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class RecipeList extends AppCompatActivity {

    ListView listview;
    ArrayList<Recipe> lists;
    ArrayAdapter<String> adapter;
    UserReference user; //ideally this is where access to current lists would come from
    ArrayList<String> listsNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_list);

        //target the listview layout in ShopList activity
        listview = findViewById(R.id.lvRecipeList);

        //instantiate a list of ingredients
        ArrayList<String> testIngredients = new ArrayList<>();
        //and a list of instructions
        ArrayList<String> testInstructions = new ArrayList<>();
        //add items to lists

        //code between these comments is debug only
        testIngredients.add("2 cups Almond Milk");
        testIngredients.add("2 Tbsp Peanut Butter");
        testIngredients.add("1 tsp Cinnamon");
        testIngredients.add("1 Banana");
        testInstructions.add("Combine ingredients in blender.");
        testInstructions.add("blend until smooth.");
        testInstructions.add("Serve topped with whipped cream and nutmeg.");
        lists = new ArrayList<>();
        Recipe test = new Recipe(1,"Peanut Butter Banana Shake", testIngredients, testInstructions);
        lists.add(test);
        listsNames = new ArrayList<>();
        for (Recipe s : lists) {
            listsNames.add(s.toString());
        }
        //the code between these comments is debug only. Remove at next phase

        //set an onitemclicklistener that catches clicks on the shopping lists.
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                System.out.println(position);
                String name = listsNames.get(position);
                Recipe item = lists.get(position); //access item and send to viewing activity
                Log.d("RecipeList", "" + name);
                //bundle the object. Helps protect it from becoming null when passed
                Bundle bundle = new Bundle();
                bundle.putSerializable("ItemModel", item);


                //create intent to open viewer activity for the list. Pass item to intent using extra for serializable items
                Intent intent = new Intent(getApplicationContext(), ItemViewer.class);
                intent.putExtra("ItemModel_bundle", bundle);
                startActivity(intent);
            }
        });

        //instantiate and set the adapter
        adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1, listsNames);
        listview.setAdapter(adapter);
    }
}